package abstarct;

	class Lion extends Animal {
	    void eat() {
	        System.out.println("Lion eats meat");
	    }

	    void sleep() {
	        System.out.println("Lion sleeps 10 hours");
	    }
	}

