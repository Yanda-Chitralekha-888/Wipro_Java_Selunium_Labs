package abstarct;


	class Tiger extends Animal {
	    void eat() {
	        System.out.println("Tiger hunts and eats deer");
	    }

	    void sleep() {
	        System.out.println("Tiger sleeps during the day");
	    }
	}


