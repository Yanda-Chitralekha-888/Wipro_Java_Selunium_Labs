package abstarct;

abstract class Shape {
	 abstract double calculateArea();
	    abstract double calculatePerimeter();
	}


