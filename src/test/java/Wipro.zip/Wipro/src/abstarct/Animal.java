package abstarct;

abstract class Animal {
    abstract void eat();
     abstract void sleep();
		}

