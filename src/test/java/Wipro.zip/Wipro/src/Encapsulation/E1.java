package Encapsulation;

public class E1 {
		private String Name;
		private int age;
		private String country;
		
		String getName()
		{
		return Name;
         }
		public void setName(  String Name)
		{
			this.Name=Name;
		}
		int  getage() 
		{
		return age;
		}
		public void setage(int age)
		{
			this.age=age;
		}
		String  getcountry()
		{
			return country;
		}
		public void setcountry( String country)
		{
		 this.country=country;
		}
		
}