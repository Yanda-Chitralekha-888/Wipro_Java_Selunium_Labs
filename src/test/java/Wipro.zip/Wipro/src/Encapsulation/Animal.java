package Encapsulation;

public abstract class Animal {
	abstract void sound();
	

	}

