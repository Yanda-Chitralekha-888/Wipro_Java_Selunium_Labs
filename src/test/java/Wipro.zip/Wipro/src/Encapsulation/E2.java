package Encapsulation;

public class E2 extends E1 {
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		E2 x=new E2();
		x.setName("Chitra");
		x.setage(22);
		x.setcountry("India");
		
		System.out.println(x.getName());
		System.out.println(x.getage());
		System.out.println(x.getcountry());
		
	}
	

}