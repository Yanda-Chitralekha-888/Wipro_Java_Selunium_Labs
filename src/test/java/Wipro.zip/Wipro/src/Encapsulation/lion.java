package Encapsulation;

public class lion extends Animal{
	void sound() {
		System.out.println("chuk chuck");
	}

}
