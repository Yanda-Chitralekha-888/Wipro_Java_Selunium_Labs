package inheritance;

public class P1 {
	public void Browser()
	{
		System.out.println("Browser is opened succesfully");
	}
	
		public void Page()
		{
			System.out.println("Page will  opened");	
		}
		public void search()
		{
			System.out.println("searching an element");
		}
		
		
	
	

}
